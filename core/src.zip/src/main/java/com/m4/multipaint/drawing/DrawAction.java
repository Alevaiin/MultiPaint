package com.m4.multipaint.drawing;

public class DrawAction {
    public enum Type { POINT, LINE }

    private final int userId;
    private final Type type;
    private final int x1, y1;
    private final int x2, y2; // igual a x1,y1 si es punto
    private final Brush brush;

    public DrawAction(int userId, int x1, int y1, int x2, int y2, Brush brush, Type type) {
        this.userId = userId;
        this.type = type;
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.brush = brush;
    }

    public void apply(Canvas canvas) {
        switch (type) {
            case POINT -> canvas.drawBrush(brush, x1, y1);
            case LINE  -> canvas.drawLine(brush, x1, y1, x2, y2);
        }
    }

    public int getUserId() { return userId; }
    public Brush getBrush() { return brush; }
}
