package com.m4.multipaint.drawing;

import java.util.ArrayList;
import java.util.List;

public class DrawSession {
    private final Canvas canvas;
    private final List<DrawAction> history;

    public DrawSession(Canvas canvas) {
        this.canvas = canvas;
        this.history = new ArrayList<>();
    }

    public void applyAction(DrawAction action) {
        action.apply(canvas);
        history.add(action);
    }

    public List<DrawAction> getHistory() {
        return history;
    }

}
